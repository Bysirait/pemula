#usr/bin/bash
clear
bi='\033[34;1m' 
i='\033[32;1m' 
pur='\033[35;1m' 
cy='\033[36;1m' 
me='\033[31;1m' 
pu='\033[37;1m' 
ku='\033[33;1m'


echo
echo -e $i"\t\t["$bi"•"$i"]"$me"───────────────────────────────────────────"$i"["$bi"•"$i"]"
echo -e $i"\t\t |"$cy"         Facebook Hacking Framework "$i"         |"
echo -e $i"\t\t |"$me"─────────────────────────────────────────────"$i"|"
echo -e $i"\t\t |"$pu" AUTHOR :"$ku" Sheikh Rishad"$i"                      |"
echo -e $i"\t\t |"$pu" FACEBOOK :"$ku" Sheikh Rishad"$i"                    |"
echo -e $i"\t\t |"$cy" ~ #!/user/bin/env python "$i"    ~              |"
echo -e $i"\t\t |"$cy" ~ print(" The Cyber Warrior ")"$i" ~              |"
echo -e $i"\t\t |"$pu" GitHub :"$ku" https://github.com/hackerrishad"$i"    |"
echo -e $i"\t\t |"$pu" Contack Gmail :"$ku" rishads546@gmail.com"$i"        |"
echo -e $i"\t\t["$bi"•"$i"]"$me"───────────────────────────────────────────"$i"["$bi"•"$i"]"
echo
echo -e $i"────────────────────────────────   "                               $i"────────────────────────────────"$i"    "$cy" "$i" "
echo -e $i"|"$me" 1"$i" |"$cy" BRUTEFORCE FB PHP        "$i"|"$i"  "$i" "  $i"|"$me"14"$i" |"$cy" PHISING FACEBOOK 1    "$i"   |"$i"    "$cy" "
echo -e $i"|"$me" 2"$i" |"$cy" BRUTEFORCE FB BR1G4D3    "$i"|"$i" "$cy" "  $i" |"$me"15"$i" |"$cy" PHISING FACEBOOK 2    "$i"   |"$i"    "
echo -e $i"|"$me" 3"$i" |"$cy" BRUTEFORCE FB iqbalz     "$i"|"$i" "$cy" "  $i" |"$me"16"$i" |"$cy" PHISING FACEBOOK 3     "$i"  |"$i"    "$cy" "
echo -e $i"|"$me" 4"$i" |"$cy" BRUTEFORCE FB MBF        "$i"|"$i" "$cy" "  $i" |"$me"17"$i" |"$cy" PHISING FACEBOOK 4     "$i"  |"$i"    "$cy" "
echo -e $i"|"$me" 5"$i" |"$cy" FACEBRUTE N1ght420       "$i"|"$i" "$cy" "  $i" ────────────────────────────────"$i"    "$cy" "$i" "
echo -e $i"|"$me" 6"$i" |"$cy" BRUTEFORCE FB            "$i"|"$i" "$cy" "  $i" |"$me"18"$i" |"$cy" INSTALL REQUIREMENT"$i"      |"$i"    "$cy" "
echo -e $i"────────────────────────────────"$i"  "$cy" "$i""     $i"|"$me"19"$i" |"$cy" EXIT PROGRAM           "$i"  |"$i"    "$cy" "
echo -e $i"|"$me" 7"$i" |"$cy" YAHOO CLONING FACEBOOK   "$i"|"$i" "           $i"  ────────────────────────────────    "  
echo -e $i"|"$me" 8"$i" |"$cy" PROFILE GUARD FACEBOOK   "$i"|"$i" "$cy" "    
echo -e $i"|"$me" 9"$i" |"$cy" REPORT FACEBOOK WORK     "$i"|"$i" "$cy" "
echo -e $i"|"$me"10"$i" |"$cy" AUTO REACTION FACEBOOK   "$i"|"$i"    "$cy" "
echo -e $i"|"$me"11"$i" |"$cy" INFORMATION FACEBOOK     "$i"|"$i"    "$cy" "
echo -e $i"|"$me"12"$i" |"$cy" BOT KOMEN FACEBOOK       "$i"|"$i"    "$cy" "
echo -e $i"|"$me"13"$i" |"$cy" AUTOLIKE FACEBOOK        "$i"|"$i"    "$cy" "
echo -e $i"────────────────────────────────    "
echo
echo -e $me"┌==="$bi"["$i"Rishad"$bi"]"$me"======"$bi"["$i""White_Hat""$bi"]"
echo -e $me"¦"
echo -e $me"¦"
read -p"└──# " pil

if [ $pil = 1 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/FR13ND8/fbbrute
cd fbbrute
php fb.php
fi

if [ $pil = 2 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/FR13ND8/Fb-Cracker-v.3
cd Fb-Cracker-v.3
python2 crack.py
fi

if [ $pil = 3 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/IqbalzNoobs/fb-brute
cd fb-brute
python2 brute.py
fi

if [ $pil = 4 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/FR13ND8/mbf
cd mbf
python2 MBF.py
fi

if [ $pil = 5 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/N1ght420/FaceBrute
cd FaceBrute
python fb.py
fi

if [ $pil = 6 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/thelinuxchoice/facebash.git
cd facebash
bash facebash.sh
fi

if [ $pil = 7 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/FR13ND8/EmailVuln
cd EmailVuln
python2 vuln.py
fi

if [ $pil = 8 ]
then
clear
figlet -f slant "W A I T"|
sleep 1
git clone https://github.com/FR13ND8/ProfileGuardFb
cd ProfileGuardFb
php guard.php
fi

if [ $pil = 9 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/IlayTamvan/Report
cd Report
unzip Report.zip
python2 Report.py
fi

if [ $pil = 10 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/AMVengeance/FB-React
cd FB-React
./start
fi

if [ $pil = 11 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/FR13ND8/InfoFB
cd InfoFB
pip2 install -r requirements.txt
python2 info.py
fi

if [ $pil = 12 ]
then
clear
figlet -f slant "W A I T"
sleep 1
pip2 install mechanize
git clone https://github.com/Senitopeng/Botkomena.git
cd Botkomena
python2 botkomena.py
fi

if [ $pil = 13 ]
then
clear
figlet -f slant "W A I T"|
sleep 1
git clone https://github.com/FR13ND8/autolike
cd autolike
php autolike.php
fi

if [ $pil = 14 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/thelinuxchoice/shellphish.git
cd shellphish
bash shellphish.sh
fi

if [ $pil = 15 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/thelinuxchoice/blackeye.git
cd blackeye
bash blackeye.sh
fi

if [ $pil = 16 ]
then
clear
figlet -f slant "W A I T"
sleep 1
git clone https://github.com/UndeadSec/SocialFish.git
cd SocialFish
chmod +x *
pip2 install -r requirements.txt
python2 SocialFish.py
fi

if [ $pil = 17 ]
then
clear
figlet -f slant "W A I T"
sleep 1
https://github.com/evait-security/weeman.git
chmod +x *
python2 weeman.py
fi

if [ $pil = 18 ]
then
clear
apt update && apt upgrade
apt install python2
apt install urllib3 chardet certifi idna requests
apt install git
apt install mechanize
apt install curl
apt install ruby
apt install gem
apt install lolcat
apt install git
apt install php
apt install ruby cowsay toilet figlet
apt install neofetch
apt install nano
figlet -f slant " S U K S E S "
fi

if [ $pil = 19 ]
then
clear
figlet -f slant "E X I T"
sleep 2
echo -e $cy"Thank You For Using My Tool"
sleep 2
echo -e $i"If You Have Mistakes You Can Ask Me"
sleep 2
echo -e $ku"GitHub :"$i" https://github.com/hackerrishad"
echo -e $ku"Facebook :"$i" Sheikh Rishad"
sleep 2
echo -e $pur">> Thanks for Supporting Me <<"
exit
fi