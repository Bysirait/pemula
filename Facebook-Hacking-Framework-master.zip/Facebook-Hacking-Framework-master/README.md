![Repository Size](https://img.shields.io/github/repo-size/hackerrishad/Facebook-Hacking-Framework)
# Facebook-Hacking-Framework

## Author: Sheikh Rishad

## Installation

Use git to clone the repository.

```bash
git clone https://github.com/hackerrishad/Facebook-Hacking-Framework
```

## Usage
Go to the cloned directory
```bash
cd Facebook-Hacking-Framework
chmod +x Facebook-Hacking-Framework.sh
```
Run the script
```bash
./Facebook-Hacking-Framework.sh
```



### Video Demo
[![Facebook Hacking Frameworka](https://img.youtube.com/vi/CwAhaq5gFO0/hqdefault.jpg)](https://youtu.be/CwAhaq5gFO0)
#### For More Video subcribe <a href="https://www.youtube.com/channel/UC1fEi8WxLne8dxsAZ5OU8bw">White Hat YouTube Channel</a>
